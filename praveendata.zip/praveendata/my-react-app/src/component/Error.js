function Error() {
    return (
        <div>
            OOps! page not found 
        </div>
    )
}

export default Error
