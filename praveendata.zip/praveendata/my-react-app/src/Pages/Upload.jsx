import Uploaddoc from "../component/Uploaddoc";

const Upload = () => {
  return (
    <>
      <h1 className="text-center font-bold m-12">Upload here</h1>
      <Uploaddoc />
    </>
  );
};

export default Upload;
